import interfaces.*;
import classes.*;
import java.lang.*;
import java.util.*;

public class Start 
{
	public static void main(String args[])
	
    {   
    	Scanner sc = new Scanner(System.in);
    	String choice;

		System.out.println("Press 1 for User login \n      2 for Admin login");
		choice = sc.nextLine();

			
		System.out.println();
		System.out.println("You Are Welcome to Diagnostic Center Billing System ");
		Diagnostic d = new Diagnostic();

		boolean choice1 = true;

		while(choice1)
		{
			System.out.print("Here are some options for you: \n");
			System.out.println("  1. Ambulance");
			System.out.println("  2. Endoscopy");
			System.out.println("  3. Mri");
			System.out.println("  4. Bill");
			System.out.println("  5. Exit Application\n");
			System.out.print("What do you want? ");

			int first = sc.nextInt();
			System.out.println();

			switch(first)
			        {
			      	    case 1:
			      	        System.out.println("Welcome to Ambulance");
			      	        System.out.print("Here are some options for you: \n");
			      	        System.out.println("  1. Book an Ambulance");
			      	        System.out.println("  2. Remove Existing Ambulance");
			      	        System.out.println("  3. See all Ambulances");
			      	        System.out.println("  4. Go Back\n");
			      	        System.out.print("What do you want? ");


			      	        int second1 = sc.nextInt();
			      	        System.out.println();

			      	        switch(second1)
			      	        {
			      	        	case 1:
			      	        	    System.out.println("You have selected to Booking an Ambulance\n");
			      	        	    System.out.println("Please Enter Patient Name: ");
			      	        	    String name = sc.next();
			      	        	    System.out.println("Enter Patient Phone Number: ");
			      	        	    long num = sc.nextLong();
			      	        	    System.out.println("Enter Patient Id:");
			      	        	    long id = sc.nextLong();
			      	        	    System.out.println("Ambulance Bill:");
			      	        	    double bill = sc.nextDouble();

    	                            Ambulance amb = new Ambulance();
    	                            amb.setAmbulanceName(name);
    	                            amb.setPhoneNumber(num);
    	                            amb.setAmbulanceId(id);
    	                            amb.setAmbulanceBill(bill);
    	                            d.insertAmbulance(amb);
    	                            break;

    	                        case 2:
    	                                    
    	                            System.out.println("You have Selected to Remove an Ambulance\n");
    	                            System.out.println("Enter Patient Id: ");
    	                            d.removeAmbulance(d.getAmbulance(sc.nextLong()));
    	                            break;
    	                                    
    	                        case 3:
    	                                    
    	                            System.out.println("You have Selected to See all Ambulance\n");
    	                            d.showAllAmbulance();
    	                            break;

    	                        case 4:
    	                                    
    	                            System.out.println("\nYou have Selected to Go Back");
    	                            break;
    	                                    
    	                        default:
    	                            System.out.println("\nInvalid Input");
    	                            break;

			      	        }
			      	        break;

			      	    case 2:
			      	        System.out.println("Welcome to Endoscopy");
			      	        System.out.print("Here are some options for you: \n");
			      	        System.out.println("  1. Endoscopy Test");
			      	        System.out.println("  2. Remove Existing Endoscopy Test");
			      	        System.out.println("  3. See all Endoscopy Test");
			      	        System.out.println("  4. Go Back");
			      	        System.out.print("\nWhat do you want? ");


			      	        int second2 = sc.nextInt();
			      	        System.out.println();

			      	        switch(second2)
			      	        {
			      	            case 1:
			      	                System.out.println("You have Selected to Endoscopy Test\n");
			      	               	System.out.println("Please Enter Patient Name: ");
			      	                String name1 = sc.next();
			      	                System.out.println("Enter Patient Phone Number: ");
			      	       	        long num1 = sc.nextLong();
			      	       	        System.out.println("Enter Patient Id");
			      	       	        long id1 = sc.nextLong();
			      	       	        System.out.println("Endoscopy Test Bill: ");
			      	       	        double bill1 = sc.nextDouble();


			      	                Endoscopy end = new Endoscopy();
			      	       	        end.setEndoscopyName(name1);
			      	       	        end.setEndoscopyPhoneNumber(num1);
			      	       	        end.setEndoscopyId(id1);
			      	       	        end.setEndoscopyBill(bill1);
			      	       	        d.insertEndoscopy(end);
			      	       	        break;

			      	       	    case 2:
			      	       	        System.out.println("You have Selected to Remove Endoscopy Test \n");
			              	        System.out.println("Enter Patient Id: ");
			   	        	        d.removeEndoscopy(d.getEndoscopy(sc.nextLong()));
			   	        	        break;

			      	            case 3:
			      	       	        System.out.println("\nYou have Selected to See all Endoscopy Test \n");
			      	       	        d.showAllEndoscopy();
			      	       	        break;
			      	       	    case 4:
			      	       	        System.out.println("\nYou have Selected to Go Back \n");
			      	       	        break;
			      	       	    default:
			      	       	        System.out.println("\nInvalid Input");
			                }
			   	            break;

			            case 3:
	  	                    System.out.println("\nWelcome to MRI Test");
		                    System.out.print("Here are some options for you: \n");
			      	        System.out.println("  1. MRI Test");
			                System.out.println("  2. Remove Existing MRI Test");
			                System.out.println("  3. See all MRI Test");
			      	        System.out.println("  4. Go Back\n");
			      	        System.out.print("What do you want? ");


			      	        int second3 = sc.nextInt();
			                System.out.println();

			      	        switch(second3)
			                {
			      	            case 1: 
			      	      	        System.out.println("You have Selected to MRI Test\n");
		            	            System.out.println("Please Enter Patient Name: ");
			      	        	    String name2 = sc.next();
			      	                System.out.println("Enter Patient Phone Number: ");
			      	        	    long num2 = sc.nextLong();
			      	                System.out.println("Enter Patient Id");
			      	                long id2 = sc.nextLong();
			      	                System.out.println("MRI Bill: ");
			      	                double bill2 = sc.nextDouble();
			      	                

			      	        	    Mri m = new Mri();
			      	        	    m.setMriName(name2);
			      	        	    m.setMriPhoneNumber(num2);
			      	        	    m.setMriId(id2);
			      	        	    m.setMriBill(bill2);
			      	        	    
			      	        	    d.insertMri(m);
			      	        	    break;

			      	            case 2:
			      	        	    System.out.println("You have Selected to Remove an Existing MRI Test");
			      	        	    System.out.println("Enter MRI Id: ");

			      	        	    d.removeMri(d.getMri(sc.nextLong()));
			      	        	    break;

			      	            case 3:
			      	        	    System.out.println("You have Selected to See all the MRI Test");
			      	        	    d.showAllMri();
			      	        	    break;

			      	        	case 4:
			      	        	    System.out.println("You have Selected to Go Back");
			      	        	    break;

			      	        	default:
			      	        	    System.out.println("Invalid Input");
			      	        	    break;   
			      	        }
                            break;
                        case 4:
			      	        System.out.println();
			      	        System.out.println("Follow The Below Option:");
			      	        System.out.println("1. Bill: ");
			      	        System.out.println("2. Go Back");
			      	        System.out.print("Select Any Option: ");			      	                   
			      	                    
			      	        int second4 = sc.nextInt();
			      	                     
			      	        switch(second4)
			      	        {
			      	            case 1:
			      	                System.out.println("Id Number: ");
			      	                int idNum = sc.nextInt();
			      	                System.out.println("Bill: ");
			      	                int bill = sc.nextInt();
			      	                System.out.println();

			      	                Bill bi = new Bill();
			      	                    	
			      	                bi.setIdNumber(idNum);
			      	                bi.setBill(bill);
			      	                
			      	                bi.showDetails();
			      	                break;

			      	           	case 2:
			      	                System.out.println("Selected to Go Back");
			      	                break;

			      	            default:
			      	                System.out.println("Invalid!"); 
			      	                break;

			      	        } 
			                break;      

			            case 5:
			      	        System.out.println("You have Selected to Exit the Application");
					        System.out.println("Thank You For Using Our Diagnostic Center Billing System ");				                       
					        choice1 = false;
					        break;
					
				        default:
			                System.out.println("Invalid Input");
			                break;
                    }
		}

	}
}