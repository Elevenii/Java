package interfaces;
import classes.*;
import java.lang.*;

public interface MriOperations
{
	void insertMri(Mri m);
	void removeMri(Mri m);
	Mri getMri(long mriId);
	void showAllMri();
}