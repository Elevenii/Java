package interfaces;
import classes.*;
import java.lang.*;

public interface EndoscopyOperations
{
	void insertEndoscopy(Endoscopy end);
	void removeEndoscopy(Endoscopy end);
	Endoscopy getEndoscopy(long endoscopyId);
	void showAllEndoscopy();
}