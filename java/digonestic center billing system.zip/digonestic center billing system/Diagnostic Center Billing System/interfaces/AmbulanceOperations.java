package interfaces;
import classes.*;
import java.lang.*;

public interface AmbulanceOperations
{
	void insertAmbulance(Ambulance amb);
	void removeAmbulance(Ambulance amb);
	Ambulance getAmbulance(long ambulanceId);
	void showAllAmbulance();
}