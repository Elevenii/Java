package classes;
import interfaces.*;
import java.lang.*;

public class Bill extends Id 
{
	private int bill;
	public void setBill(int bill)
	{
		this.bill = bill;
	}
	public int getBill(){ return bill;}

	public void showInfo(){}
	public void showDetails()
	{
		System.out.println("Bill: "+bill);
		super.showDetails();
	}
}
