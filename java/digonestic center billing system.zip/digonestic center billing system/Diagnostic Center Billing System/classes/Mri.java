package classes;
import interfaces.*;
import java.lang.*;

public class Mri 
{
	private long mriId;
	private String mriName;
	private double mriBill;
    private long mriPhoneNumber;

    public void setMriId(long mriId){ this.mriId=mriId;}
    public void setMriName(String mriName){ this.mriName=mriName;}
    public void setMriBill(double mriBill){ this.mriBill=mriBill;}
    public void setMriPhoneNumber(long mriPhoneNumber){ this.mriPhoneNumber=mriPhoneNumber;}

    public long getMriId(){ return mriId;}
    public String getMriName(){ return mriName;}
    public double getMriBill(){ return mriBill;}
    public long getMriPhoneNumber(){ return mriPhoneNumber;}

    public void showDetails()
    {
    	System.out.println("Patient Name: "+mriName);
    	System.out.println("Patient Id: "+mriId);
    	System.out.println("Patient Phone Number: "+mriPhoneNumber);
    	System.out.println("Mri Bill: "+mriBill);
    }
    
}