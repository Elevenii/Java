package classes;
import java.lang.*;
import interfaces.*;

public class Ambulance implements IdOperations
{
	private String ambulanceName;
	private long phoneNumber;
	private long ambulanceId;
	private double ambulanceBill;
	private Id id[] = new Id[20];

	public void setAmbulanceName(String ambulanceName){ this.ambulanceName=ambulanceName;}
	public void setPhoneNumber(long phoneNumber){ this.phoneNumber=phoneNumber;}
	public void setAmbulanceId(long ambulanceId){ this.ambulanceId=ambulanceId;}
	public void setAmbulanceBill(double ambulanceBill){ this.ambulanceBill=ambulanceBill;}

	public String getAmbulanceName(){ return ambulanceName;}
	public long getPhoneNumber(){ return phoneNumber;}
	public long getAmbulanceId(){ return ambulanceId;}
	public double getAmbulanceBill(){ return ambulanceBill;}

	public void insertId(Id a)
	{
		int flag = 0;
		for(int i =0; i<id.length; i++)
		{
			if(id[i] == null)
			{
				id[i]=a;
				flag=1;
				break;
			}

		}
		if(flag == 1){ System.out.println("Id Inserted");}
		else{ System.out.println("Can Not Insert Id");}
	}

	public void removeId(Id a)
	{
        int flag = 0;
		for(int i = 0; i<id.length; i++)
		{
			if(id[i] == a)
			{
                id[i] = null;
                flag = 1;
                break;
			}
		}
		if(flag == 1){ System.out.println("Ambulance Removed");}
		else{ System.out.println("Can Not Remove Ambulance");}
	}

	public Id getId(long idNumber)
	{
		Id a = null;
		for(int i = 0; i<id.length; i++)
		{
			if(id[i] != null)
			{
				if(id[i].getIdNumber() == idNumber)
				{
					a = id[i];
					break;
				}
			}
		}
		if(a != null)
		{
			System.out.println("Id Found");
		}
		else
		{
			System.out.println("Id Not Found");
		}
		return a;
	}
	
	public void showAllId()
	{
		for(int i=0; i<id.length; i++)
		{
			if(id[i] != null)
			{
				id[i].showDetails();
				System.out.println();
			}
		}
	}

	public void showDetails()
	{
		System.out.println("Patient Name: "+ambulanceName);
		System.out.println("Patient Phone Number: "+phoneNumber);
		System.out.println("Patient Id: "+ambulanceId);
	}
}