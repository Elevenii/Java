package classes;
import interfaces.*;
import java.lang.*;

public class Endoscopy
{
	private long endoscopyId;
	private String endoscopyName;
	private double endoscopyBill;
    private long endoscopyPhoneNumber;

    public void setEndoscopyId(long endoscopyId){ this.endoscopyId=endoscopyId;}
    public void setEndoscopyName(String endoscopyName){ this.endoscopyName=endoscopyName;}
    public void setEndoscopyBill(double endoscopyBill){ this.endoscopyBill=endoscopyBill;}
    public void setEndoscopyPhoneNumber(long endoscopyPhoneNumber){ this.endoscopyPhoneNumber=endoscopyPhoneNumber;}

    public long getEndoscopyId(){ return endoscopyId;}
    public String getEndoscopyName(){ return endoscopyName;}
    public double getEndoscopyBill(){ return endoscopyBill;}
    public long getEndoscopyPhoneNumber(){ return endoscopyPhoneNumber;}

    public void showDetails()
    {
    	System.out.println("Patient Name: "+endoscopyName);
    	System.out.println("Patient Id: "+endoscopyId);
    	System.out.println("Patient Phone Number: "+endoscopyPhoneNumber);
    	System.out.println("Endoscopy Bill: "+endoscopyBill);
    }
}