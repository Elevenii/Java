package classes;
import interfaces.*;
import java.lang.*;

public abstract class Id 
{
    protected long idNumber;
    
    public void setIdNumber(long idNumber){ this.idNumber=idNumber;}
    public long getIdNumber(){ return idNumber;}
    
    public abstract void showInfo();

    public void showDetails()
    {
      System.out.println("Id Number: "+idNumber);
    }

}