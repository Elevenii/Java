package classes;
import interfaces.*;
import java.lang.*;

public class Diagnostic implements AmbulanceOperations, EndoscopyOperations, MriOperations
{
    private Ambulance ambulances[] = new Ambulance[100];
    private Endoscopy endoscopys[] = new Endoscopy[100];
    private Mri mris[] = new Mri[100];

    public void insertAmbulance(Ambulance amb)
    {
    	int flag = 0;
    	for(int i = 0; i<ambulances.length; i++)
    	{
    		if(ambulances[i] == null)
    		{
    			ambulances[i] = amb;
    			flag = 1;
    			break;
    		}
    	}
    	if(flag == 1){System.out.println("Ambulance Inserted");}
    	else {System.out.println("Ambulance Can Not Insert");}
    }

    public void removeAmbulance(Ambulance amb)
    {
        int flag = 0;
    	for(int i = 0; i<ambulances.length; i++)
    	{
    		if(ambulances[i] == amb)
    		{
    			ambulances[i] = null;
    			flag = 1;
    			break;
    		}
    	}
    	if(flag == 1){System.out.println("Ambulance Removed ");}
    	else {System.out.println("Ambulance Can Not Remove");}
    }

    public Ambulance getAmbulance(long ambulanceId)
	{
		Ambulance amb = null;
		for(int i = 0; i<ambulances.length; i++)
		{
			if(ambulances[i] != null)
			{
				if(ambulances[i].getAmbulanceId() == ambulanceId)
				{
					amb = ambulances[i];
					break;
				}
			}
		}
		if(amb != null)
		{
			System.out.println("Ambulance Found");
		}
		else
		{
			System.out.println("Ambulance Not Found");
		}
	     return amb;
	}
	
	public void showAllAmbulance()
	{
		for(int i = 0; i<ambulances.length; i++)
		{
			if(ambulances[i] != null)
			{
				ambulances[i].showDetails();
				System.out.println();
			}
		}
	}

	public void insertEndoscopy(Endoscopy end)
    {
    	int flag = 0;
    	for(int i = 0; i<endoscopys.length; i++)
    	{
    		if(endoscopys[i] == null)
    		{
    			endoscopys[i] = end;
    			flag = 1;
    			break;
    		}
    	}
    	if(flag == 1){System.out.println("Endoscopy Inserted");}
    	else {System.out.println("Endoscopy Can Not Insert");}
    }

    public void removeEndoscopy(Endoscopy end)
    {
        int flag = 0;
    	for(int i = 0; i<endoscopys.length; i++)
    	{
    		if(endoscopys[i] == end)
    		{
                endoscopys[i] = null;
    			flag = 1;
    			break;
    		}
    	}
    	if(flag == 1){System.out.println("Endoscopy Removed ");}
    	else {System.out.println("Endoscopy Can Not Remove");}
    }

    public Endoscopy getEndoscopy(long endoscopyId)
	{
		Endoscopy end = null;
		for(int i = 0; i<endoscopys.length; i++)
		{
			if(endoscopys[i] != null)
			{
				if(endoscopys[i].getEndoscopyId() == endoscopyId)
				{
					end = endoscopys[i];
					break;
				}
			}
		}
		if(end != null)
		{
			System.out.println("Endoscopy Found");
		}
		else
		{
			System.out.println("Endoscopy Not Found");
		}
	     return end;
	}
	
	public void showAllEndoscopy()
	{
		for(int i = 0; i<endoscopys.length; i++)
		{
			if(endoscopys[i] != null)
			{
				endoscopys[i].showDetails();
				System.out.println();
			}
		}
	}

	public void insertMri(Mri m)
    {
    	int flag = 0;
    	for(int i = 0; i<mris.length; i++)
    	{
    		if(mris[i] == null)
    		{
    			mris[i] = m;
    			flag = 1;
    			break;
    		}
    	}
    	if(flag == 1){System.out.println("Mri Inserted");}
    	else {System.out.println("Mri Can Not Inserted");}
    }

    public void removeMri(Mri m)
    {
        int flag = 0;
    	for(int i = 0; i<mris.length; i++)
    	{
    		if(mris[i] == m)
    		{
    			mris[i] = null;
    			flag = 1;
    			break;
    		}
    	}
    	if(flag == 1){System.out.println("Mri Removed ");}
    	else {System.out.println("Mri Can Not Remove");}
    }

    public Mri getMri(long mriId)
	{
		Mri m = null;
		for(int i = 0; i<mris.length; i++)
		{
			if(mris[i] != null)
			{
				if(mris[i].getMriId() == mriId)
				{
					m = mris[i];
					break;
				}
			}
		}
		if(m != null)
		{
			System.out.println("Mri Found");
		}
		else
		{
			System.out.println("Mri Not Found");
		}
	     return m;
	}
	
	public void showAllMri()
	{
		for(int i = 0; i<mris.length; i++)
		{
			if(mris[i] != null)
			{
				mris[i].showDetails();
				System.out.println();
			}
		}
	} 
 
}